package DataBase;

public final class Constants {
    public static final Integer NUMBER_OF_FREE_MOVIES = 15;
    public static final Integer BUY_PREMIUM_ACC = 10;
    public static final Integer RATE_MAX = 5;

    private Constants() {

    }
}
